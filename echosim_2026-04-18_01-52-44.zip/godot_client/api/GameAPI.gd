## GameAPI.gd — HTTP-клиент к echo-sim server.py со стримингом
extends Node

signal token_received(token: String)       # токен во время стриминга
signal response_done(narrative: String, state: Dictionary)  # финал
signal state_received(state: Dictionary)
signal error_occurred(message: String)
signal connected(ok: bool)

var server_url: String = "http://127.0.0.1:8080"
var _host: String = "127.0.0.1"
var _port: int = 8080
var _use_ssl: bool = false

var _http_check: HTTPRequest  # для ping и /state
var _streaming: bool = false
var _client: HTTPClient
var _stream_thread: Thread
var _stream_buf: String = ""
var _pending_command: String = ""


func _ready() -> void:
	_http_check = HTTPRequest.new()
	_http_check.timeout = 10.0
	add_child(_http_check)
	_client = HTTPClient.new()


func set_server_url(url: String) -> void:
	server_url = url.rstrip("/")
	# Парсим host и port
	var u = url.replace("http://", "").replace("https://", "")
	_use_ssl = url.begins_with("https")
	if ":" in u:
		_host = u.split(":")[0]
		_port = int(u.split(":")[1].split("/")[0])
	else:
		_host = u.split("/")[0]
		_port = 443 if _use_ssl else 80


func check_connection() -> void:
	_http_check.request_completed.connect(_on_ping_done, CONNECT_ONE_SHOT)
	_http_check.request(server_url + "/state", ["ngrok-skip-browser-warning: true"])


func get_state() -> void:
	_http_check.request_completed.connect(_on_state_done, CONNECT_ONE_SHOT)
	_http_check.request(server_url + "/state", ["ngrok-skip-browser-warning: true"])


func reset_game() -> void:
	_http_check.request_completed.connect(_on_reset_done, CONNECT_ONE_SHOT)
	_http_check.request(
		server_url + "/reset",
		["Content-Type: application/json"],
		HTTPClient.METHOD_POST,
		"{}"
	)


func send_command(command: String) -> void:
	if _streaming:
		return
	_pending_command = command
	_streaming = true
	_stream_buf = ""
	# Запускаем стриминг в отдельном потоке
	_stream_thread = Thread.new()
	_stream_thread.start(_stream_worker.bind(command))


func _stream_worker(command: String) -> void:
	"""Читает chunked-ответ от /stream в отдельном потоке."""
	var client = HTTPClient.new()
	var err = client.connect_to_host(_host, _port)
	if err != OK:
		call_deferred("_on_stream_error", "Не удалось подключиться к серверу")
		return

	# Ждём подключения
	var attempts = 0
	while client.get_status() in [HTTPClient.STATUS_CONNECTING, HTTPClient.STATUS_RESOLVING]:
		client.poll()
		OS.delay_msec(10)
		attempts += 1
		if attempts > 300:
			call_deferred("_on_stream_error", "Таймаут подключения")
			return

	if client.get_status() != HTTPClient.STATUS_CONNECTED:
		call_deferred("_on_stream_error", "Сервер недоступен")
		return

	var body = JSON.stringify({"command": command})
	var headers = [
		"Content-Type: application/json",
		"Content-Length: " + str(body.to_utf8_buffer().size()),
		"ngrok-skip-browser-warning: true",
	]
	err = client.request(HTTPClient.METHOD_POST, "/stream", headers, body)
	if err != OK:
		call_deferred("_on_stream_error", "Ошибка запроса")
		return

	# Ждём заголовки
	while client.get_status() == HTTPClient.STATUS_REQUESTING:
		client.poll()
		OS.delay_msec(10)

	if client.get_status() != HTTPClient.STATUS_BODY:
		call_deferred("_on_stream_error", "Нет ответа от сервера")
		return

	# Читаем тело чанками
	var full_text = ""
	while client.get_status() == HTTPClient.STATUS_BODY:
		client.poll()
		var chunk = client.read_response_body_chunk()
		if chunk.size() > 0:
			var text = chunk.get_string_from_utf8()
			full_text += text
			# Проверяем — не финальный ли это state-чанк
			if "__state__" in text:
				# Разделяем нарратив и state
				var parts = full_text.split('{"__state__":', true, 1)
				if parts.size() > 0:
					var narrative_part = parts[0].strip_edges()
					call_deferred("_emit_token", narrative_part.substr(
						maxi(0, narrative_part.length() - text.length())
					))
				break
			else:
				call_deferred("_emit_token", text)
		else:
			OS.delay_msec(5)

	client.close()

	# Парсим финальный state из full_text
	var state = {}
	var state_match = RegEx.new()
	state_match.compile('\\{"__state__":\\s*(\\{.*\\})')
	var result = state_match.search(full_text)
	if result:
		var json = JSON.new()
		if json.parse(result.get_string(1)) == OK:
			state = json.get_data()

	# Нарратив — всё до __state__
	var narrative = full_text
	var state_idx = full_text.find('{"__state__"')
	if state_idx > 0:
		narrative = full_text.substr(0, state_idx).strip_edges()

	call_deferred("_on_stream_done", narrative, state)


func _emit_token(token: String) -> void:
	if token.strip_edges() != "":
		token_received.emit(token)


func _on_stream_done(narrative: String, state: Dictionary) -> void:
	_streaming = false
	if _stream_thread and _stream_thread.is_started():
		_stream_thread.wait_to_finish()
	response_done.emit(narrative, state)


func _on_stream_error(message: String) -> void:
	_streaming = false
	if _stream_thread and _stream_thread.is_started():
		_stream_thread.wait_to_finish()
	error_occurred.emit(message)


func _on_ping_done(result: int, code: int, _h, _b) -> void:
	connected.emit(result == HTTPRequest.RESULT_SUCCESS and code == 200)


func _on_state_done(result: int, code: int, _h, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		return
	var json = JSON.new()
	if json.parse(body.get_string_from_utf8()) == OK:
		state_received.emit(json.get_data())


func _on_reset_done(result: int, code: int, _h, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		error_occurred.emit("Ошибка сброса")
		return
	var json = JSON.new()
	if json.parse(body.get_string_from_utf8()) == OK:
		state_received.emit(json.get_data().get("state", {}))
